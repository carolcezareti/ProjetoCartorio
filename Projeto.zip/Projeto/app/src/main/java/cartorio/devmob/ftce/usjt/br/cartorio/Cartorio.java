package cartorio.devmob.ftce.usjt.br.cartorio;

/**
 * Created by carol on 07/04/2018.
 */

public class Cartorio {
}
