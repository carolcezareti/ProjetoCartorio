package cartorio.devmob.ftce.usjt.br.cartorio;

import android.widget.ListAdapter;

import java.util.ArrayList;

/**
 * Created by carol on 07/04/2018.
 */

public class CartorioAdapter {
    public CartorioAdapter(ListarServicosActivity listarServicosActivity, ArrayList<Cartorio> cartorios) {
    }
}
