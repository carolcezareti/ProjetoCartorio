package cartorio.devmob.ftce.usjt.br.cartorio;

import java.util.ArrayList;

/**
 * Created by carol on 07/04/2018.
 */

public class CartorioNetwork {
    public static ArrayList<Cartorio> gerarSenha(String string) {

    }
}
