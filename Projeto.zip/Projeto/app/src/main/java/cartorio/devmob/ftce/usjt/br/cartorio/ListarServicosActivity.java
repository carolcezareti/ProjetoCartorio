package cartorio.devmob.ftce.usjt.br.cartorio;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

import static android.content.Intent.getIntent;

/**
 * Created by carol on 07/04/2018.
 */

public class ListarServicosActivity {
    public static final String CARTORIO = "br.usjt.deswebmob.cartorio.cartorio";
    ArrayList<Cartorio> cartorios;
    ListView listView;
    Activity contexto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        contexto.onCreate();
        contexto.setContentView();
        Intent intent = getIntent();
        cartorios = (ArrayList<Cartorio>)intent.getSerializableExtra(MainActivity.CARTORIO);
        listView = (ListView) listView.findViewById();
        CartorioAdapter adapter = new CartorioAdapter(this, cartorios);
        listView.setAdapter(adapter);
        contexto = this;

        listView.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {

                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        Cartorio chamado = cartorios.get(position);
                        Intent intent1 = new Intent(contexto , DetalheCartorioActivity.class);
                        intent1.putExtra(CARTORIO, cartorios);
                        contexto.startActivity();
                    }
                }
        );
    }
}
