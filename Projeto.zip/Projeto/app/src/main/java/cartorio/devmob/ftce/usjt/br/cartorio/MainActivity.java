package cartorio.devmob.ftce.usjt.br.cartorio;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends Activity {
    public static final String CARTORIO = "br.usjt.deswebmob.cartorio.cartorio";
    ArrayList<Cartorio> cartorio = new ArrayList<>();
    private EditText txtFila;
    Context contexto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtFila = (EditText)findViewById(R.id.tipo_servico);
        contexto = this;
    }

    public void gerarSenha(View view) {
        String fila = txtFila.getText().toString();
        new DownloadJsonChamados().execute("http://10.70.11.162:8080/arqsw_sdesk_a4_solucao_parcial/rest/chamados");

    }

    public void atendimentopref(View view) {
    }

    public void atendimentonorm(View view) {
    }

    private class DownloadJsonChamados extends AsyncTask<String, Void, ArrayList<Cartorio>> {

        private ArrayList<Cartorio> cartorio;

        @Override
        protected ArrayList<Cartorio> doInBackground(String... strings) {
            cartorio = CartorioNetwork.gerarSenha(strings[0]);
            return cartorio;
        }
    }

    protected void onPostExecute(ArrayList<Cartorio> cartorio){
        Intent intent = new Intent(contexto, ListarServicosActivity.class);
        intent.putExtra(CARTORIO, cartorio);
        startActivity(intent);
    }

}



